export TERM=xterm-256color
export HOME=/root
alias ll='ls -la'
clear
echo "Welcome to UbuntuCLI Droid 🚀"
